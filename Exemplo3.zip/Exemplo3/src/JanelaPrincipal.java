import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JFrame;
import javax.swing.JPanel;


class PainelDesenho extends JPanel {

    private int count = 0;
    private Image imagem;
    private int x = 0, y = 0;
    private List<Forma> listaFormas;
    
    public PainelDesenho(){
        
         setBackground(Color.white);
         listaFormas = new ArrayList<Forma>();
   
        addMouseListener(new MouseAdapter(){
            @Override
            public void mouseClicked(MouseEvent me) {
                super.mouseClicked(me);
                count ++;
                
                x = me.getX();
                y = me.getX();
                Forma f = null;
                if (me.getButton() == MouseEvent.BUTTON1)
                    f = new Quadrado(x, y, 60);
                else if (me.getButton() == MouseEvent.BUTTON3)
                    f = new Circulo(x, y, 30);
                listaFormas.add(f);
                
                repaint();
                System.out.println("Click do mouse! x=" + x + ", Y=" + y);
            }
            
        });
    
        
    }
    //Reimplementando função de desenho
    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g); 
        //Criando desenhos
        Graphics2D g2d = (Graphics2D)g;
     //   g2d.drawRect(10,10,120,120);
    //    g2d.fillRect(10, 140, 120, 120);
        //Mudar a cor do desenho
        //g2d.setColor(Color.magenta);
    //    g2d.drawOval(140,10,120,120);
     //   g2d.fillOval(140, 140, 120, 120);

       // g2d.setColor(Color.black);
        //g2d.drawString("Texto de teste da aula", 10, 270);
        
        //Mostra contador de desenho
     //   count++;
        //g2d.drawString("Count: " + count, 10, 285);
        
        //Desenha linha no panel
        //g2d.drawLine(50,50, 500,500);
        //Desenha a imagem
      //  g2d.drawImage(imagem,10,305,this);
      
        for (Forma forma : listaFormas) {
            forma.desenha(g2d);
        }
        
    }
    

}
public class JanelaPrincipal extends JFrame{
    
    public JanelaPrincipal(){
        
        //Colocando o título da janela
        setTitle("Computação Gráfica - Fainor");
        
        //Criando painel interno
        PainelDesenho painel = new PainelDesenho();
        //painel.setBackground(Color.black);
        //Adiciona o painel
        add(painel);
        
        //Setando o tamanho da janela
        setSize(800, 600);
        
        //Setando visibilidade
        setVisible(true);
        
        //Comportamento ao fechar
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
    
    public static void main(String[] args){
        
        System.out.println("Criando e abrindo janela...");
        JanelaPrincipal app = new JanelaPrincipal();
        
    }
}
