
import java.awt.Color;
import java.awt.Graphics2D;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author aluno
 */
public class Circulo extends Forma {
    private int raio;
    
    public Circulo(int x, int y) {
        super(x, y);
        setCor(Color.cyan);
    }
    
    public Circulo(int x, int y, int raio) {
        super(x, y);
        this.raio = raio;
        setCor(Color.cyan);
    }

    public int getRaio() {
        return raio;
    }

    public void setRaio(int raio) {
        this.raio = raio;
    }

    @Override
    public void desenha(Graphics2D g2d) {
       g2d.setColor(getCor());
       g2d.fillOval(getX(), getY(), getRaio() * 2, getRaio() * 2);
       g2d.setColor(Color.black);
       g2d.drawOval(getX(), getY(), getRaio() * 2, getRaio() * 2);
    }
    
}
