
import java.awt.Color;
import java.awt.Graphics2D;


public class Quadrado extends Forma {
    private int lado;
    
    
    public Quadrado(int x, int y) {
        super(x, y);
    }
    
    public Quadrado(int x, int y, int lado) {
        super(x, y);
        this.lado = lado;
    }

    public int getLado() {
        return lado;
    }

    public void setLado(int lado) {
        this.lado = lado;
    }

    @Override
    public void desenha(Graphics2D g2d) {
       g2d.setColor(getCor());
       g2d.fillRect(getX(), getY(), getLado(), getLado());
       g2d.setColor(Color.black);
       g2d.drawRect(getX(), getY(), getLado(), getLado());
    }
    
}